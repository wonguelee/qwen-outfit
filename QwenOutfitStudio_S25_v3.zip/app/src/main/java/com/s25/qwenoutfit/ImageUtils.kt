package com.s25.qwenoutfit

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.OutputStream

/**
 * 이미지 불러오기 / 마스크 변환 / 갤러리 저장 같은 잡일을 모아둔 곳.
 * AI 엔진은 8 또는 16의 배수 크기만 받기 때문에 여기서 크기를 정리해서 넘긴다.
 */
object ImageUtils {

    /** 폰 메모리를 아끼기 위해 긴 쪽을 이 크기로 줄여서 작업한다. */
    const val WORK_MAX_SIDE = 1024

    private const val SIZE_MULTIPLE = 16

    fun decodeSampled(context: Context, uri: Uri, maxSide: Int = WORK_MAX_SIDE): Bitmap? {
        var decoded: Bitmap? = null
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            val s1 = context.contentResolver.openInputStream(uri) ?: return null
            s1.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) {
                sample *= 2
            }

            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888

            val s2 = context.contentResolver.openInputStream(uri) ?: return null
            decoded = s2.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Exception) {
            return null
        }

        val base = decoded ?: return null
        val rotation = readRotation(context, uri)
        val rotated = if (rotation != 0f) rotate(base, rotation) else base
        if (rotated !== base) base.recycle()
        return fitToCanvas(rotated, maxSide)
    }

    /** 긴 쪽을 maxSide 이하로 줄이고, 가로·세로를 16의 배수로 맞춘다. */
    fun fitToCanvas(src: Bitmap, maxSide: Int = WORK_MAX_SIDE): Bitmap {
        var current = src
        val longest = maxOf(src.width, src.height)
        if (longest > maxSide) {
            val ratio = maxSide.toFloat() / longest.toFloat()
            val w = (src.width * ratio).toInt().coerceAtLeast(SIZE_MULTIPLE)
            val h = (src.height * ratio).toInt().coerceAtLeast(SIZE_MULTIPLE)
            current = Bitmap.createScaledBitmap(src, w, h, true)
        }
        val w2 = ((current.width / SIZE_MULTIPLE) * SIZE_MULTIPLE).coerceAtLeast(SIZE_MULTIPLE)
        val h2 = ((current.height / SIZE_MULTIPLE) * SIZE_MULTIPLE).coerceAtLeast(SIZE_MULTIPLE)
        if (w2 == current.width && h2 == current.height) return current
        return Bitmap.createScaledBitmap(current, w2, h2, true)
    }

    fun rotate(src: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix()
        matrix.postRotate(degrees)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    private fun readRotation(context: Context, uri: Uri): Float {
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return 0f
            val exif = input.use { ExifInterface(it) }
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
    }

    /** 작업용 빈 마스크(전부 투명 = 아무것도 안 바꿈). */
    fun createEmptyMask(width: Int, height: Int): Bitmap =
        Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
            it.eraseColor(0)
        }

    fun copy(src: Bitmap): Bitmap = src.copy(Bitmap.Config.ARGB_8888, true)

    fun toPngBytes(src: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        src.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }

    fun toBase64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    fun decodeBase64Image(value: String): Bitmap? {
        return try {
            val clean = if (value.contains(",")) value.substring(value.indexOf(",") + 1) else value
            val bytes = Base64.decode(clean, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * 화면용 마스크(선택된 곳만 반투명 빨강)를
     * AI 엔진이 쓰는 흑백 PNG(흰색 = 바꿀 곳 / 검은색 = 그대로 둘 곳)로 바꾼다.
     */
    fun maskToPngBytes(mask: Bitmap): ByteArray {
        val w = mask.width
        val h = mask.height
        val pixels = IntArray(w * h)
        mask.getPixels(pixels, 0, w, 0, 0, w, h)
        val outPixels = IntArray(w * h)
        for (i in pixels.indices) {
            val alpha = (pixels[i] ushr 24) and 0xFF
            outPixels[i] = if (alpha >= 96) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(outPixels, 0, w, 0, 0, w, h)
        val bytes = toPngBytes(out)
        out.recycle()
        return bytes
    }

    fun saveToGallery(context: Context, bitmap: Bitmap, baseName: String): Boolean {
        return try {
            val values = ContentValues()
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "$baseName.png")
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/QwenOutfit"
                )
                values.put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            val stream: OutputStream? = resolver.openOutputStream(uri) ?: return false
            stream.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues()
                done.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, done, null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}