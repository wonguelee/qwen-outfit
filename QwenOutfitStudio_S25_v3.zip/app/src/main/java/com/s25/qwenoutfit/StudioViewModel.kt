package com.s25.qwenoutfit

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * 앱의 상태(사진, 마스크, 프롬프트, 설정값)와 동작(자동선택, 실행, 저장)을 담당.
 *
 * 마스크는 화면용 표현으로 저장한다 — "선택된 곳만 반투명 빨강".
 * 엔진에 보낼 때만 ImageUtils.maskToPngBytes() 가 흑백 PNG 로 바꿔준다
 * (흰색 = 바꿀 곳 / 검은색 = 그대로 둘 곳).
 */
class StudioViewModel(app: Application) : AndroidViewModel(app) {

    // ------------------------------------------------------------- 엔진 / 설정

    var serverUrl by mutableStateOf("http://127.0.0.1:1234")
    var useImg2Img by mutableStateOf(false)
    var sendExtraArgs by mutableStateOf(true)

    var steps by mutableStateOf(8f)
    var cfgScale by mutableStateOf(2.5f)
    var flowShift by mutableStateOf(3.0f)
    var strength by mutableStateOf(0.85f)
    var seedText by mutableStateOf("-1")

    // --------------------------------------------------------------- 프롬프트

    var prompt by mutableStateOf("")
    var negativePrompt by mutableStateOf("")
    var autoAppendKeep by mutableStateOf(true)
    var showAdvanced by mutableStateOf(false)

    // ----------------------------------------------------------------- 도구

    var eraser by mutableStateOf(false)
    var brushSize by mutableStateOf(40f)          // 지름 (dp)
    var keepFaceAndHair by mutableStateOf(true)   // 자동선택 시 얼굴·머리 보호

    // ----------------------------------------------------------------- 상태

    var source by mutableStateOf<Bitmap?>(null)
    var result by mutableStateOf<Bitmap?>(null)
    var preview by mutableStateOf<Bitmap?>(null)
    var maskVersion by mutableStateOf(0)
    var running by mutableStateOf(false)
    var progress by mutableStateOf(0f)
    var status by mutableStateOf("사진을 불러오고, 바꿀 옷 부분을 칠한 다음 실행해줘.")
    var engineMessage by mutableStateOf("엔진 확인 전")
    var hasAutoModel by mutableStateOf(false)
    var showSettings by mutableStateOf(false)

    /** 화면에 그릴 마스크(직접 픽셀을 칠하므로 State 로 두지 않는다). maskVersion 으로 갱신을 알린다. */
    var maskBitmap: Bitmap? = null
        private set

    private val segmenter by lazy { ClothingSegmenter(getApplication()) }
    private var engineClient: QwenEngineClient? = null

    private var maskCanvas: Canvas? = null
    private var canvasBitmap: Bitmap? = null

    private val brushPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(150, 255, 60, 80)
    }

    private val eraserPaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.BLACK
        alpha = 255
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val mergePaint = Paint().apply {
        isAntiAlias = true
        isFilterBitmap = true
        alpha = 255
    }

    init {
        hasAutoModel = segmenter.modelAvailable()
    }

    // ------------------------------------------------------------------ 사진

    fun loadPhoto(context: Context, uri: Uri) {
        val bitmap = ImageUtils.decodeSampled(context, uri)
        if (bitmap == null) {
            status = "사진을 열지 못했어. 다른 사진으로 해봐."
            return
        }
        // 표시 중인 이미지는 절대 recycle 하지 않는다 (그리는 도중이면 앱이 죽는다).
        // 한 장에 4MB 정도라 그냥 GC 에 맡기는 게 안전하다.
        source = bitmap
        result = null
        preview = null
        maskBitmap = ImageUtils.createEmptyMask(bitmap.width, bitmap.height)
        maskCanvas = null
        canvasBitmap = null
        maskVersion++
        status = "${bitmap.width} x ${bitmap.height} 사진을 불러왔어. 옷 부분을 칠하거나 '옷 자동 선택'을 눌러."
    }

    // ------------------------------------------------------------------ 마스크

    private fun canvasFor(bitmap: Bitmap): Canvas {
        val cached = maskCanvas
        if (cached != null && canvasBitmap === bitmap) return cached
        val created = Canvas(bitmap)
        maskCanvas = created
        canvasBitmap = bitmap
        return created
    }

    /** 좌표는 이미 비트맵 기준으로 환산돼서 들어온다. */
    fun paint(x0: Float, y0: Float, x1: Float, y1: Float, radiusPx: Float, erase: Boolean) {
        val bitmap = maskBitmap ?: return
        val canvas = canvasFor(bitmap)
        val paint = if (erase) eraserPaint else brushPaint
        val radius = radiusPx.coerceIn(1f, 600f)
        paint.strokeWidth = radius * 2f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(x0, y0, x1, y1, paint)
        paint.style = Paint.Style.FILL
        canvas.drawCircle(x1, y1, radius, paint)
        maskVersion++
    }

    fun clearMask() {
        val bitmap = maskBitmap ?: return
        bitmap.eraseColor(0)
        maskVersion++
        status = "마스크를 전부 지웠어."
    }

    /** 흰색/검은색이 반대로 동작하는 엔진 버전을 위한 안전장치. */
    fun invertMask() {
        val bitmap = maskBitmap ?: return
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        for (i in pixels.indices) {
            val alpha = (pixels[i] ushr 24) and 0xFF
            pixels[i] = if (alpha >= 96) Color.TRANSPARENT else Color.argb(150, 255, 60, 80)
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        maskVersion++
        status = "마스크를 반전했어. (결과가 반대로 나올 때 눌러줘)"
    }

    /** MediaPipe 로 옷 영역을 자동으로 골라 마스크 위에 얹는다. */
    fun autoSelectClothes() {
        val bitmap = source ?: run {
            status = "먼저 사진을 불러와줘."
            return
        }
        if (running) return
        viewModelScope.launch {
            status = "옷 영역을 찾는 중..."
            val piece = segmenter.clothesMask(bitmap, keepFaceAndHair)
            if (piece == null) {
                status = if (hasAutoModel) {
                    "옷을 찾지 못했어. 인물이 크게 나온 사진으로 해보거나 손으로 칠해줘."
                } else {
                    "앱에 옷 인식 모델(assets/selfie_multiclass_256x256.tflite)이 없어. 손으로 칠해줘."
                }
                return@launch
            }
            val mask = maskBitmap
            if (mask != null) {
                canvasFor(mask).drawBitmap(piece, 0f, 0f, mergePaint)
                piece.recycle()
                maskVersion++
                status = "옷 영역을 자동으로 선택했어. 브러시로 손보고 실행해."
            }
        }
    }

    // ------------------------------------------------------------------ 실행

    private fun buildPrompt(): String {
        val base = prompt.trim()
        if (base.isBlank()) return ""
        if (!autoAppendKeep) return base
        return "$base, keep the person's face, hairstyle, body shape, pose and background " +
            "exactly the same, change only the clothing"
    }

    fun checkEngine() {
        viewModelScope.launch {
            engineMessage = "확인 중..."
            val client = QwenEngineClient(serverUrl)
            val statusResult = client.check()
            engineMessage = statusResult.message
        }
    }

    fun generate() {
        val bitmap = source ?: run {
            status = "먼저 사진을 불러와줘."
            return
        }
        if (running) return

        val finalPrompt = buildPrompt()
        if (finalPrompt.isBlank()) {
            status = "어떤 옷으로 바꿀지 프롬프트에 적어줘."
            return
        }

        val mask = maskBitmap
        val client = QwenEngineClient(serverUrl)
        engineClient = client

        viewModelScope.launch {
            running = true
            result = null
            preview = null
            progress = 0f
            status = "엔진에 보냈어. 오래 걸리니까 화면을 꺼두지 마."

            var pollJob: Job? = null
            if (useImg2Img) {
                pollJob = launch {
                    while (isActive) {
                        delay(1500)
                        val (value, image) = client.progressOnce()
                        if (value > 0f) {
                            progress = value
                            if (image != null) preview = image
                        }
                    }
                }
            }

            val parsedSeed = seedText.trim().toLongOrNull() ?: -1L
            val params = QwenEngineClient.EditParams(
                prompt = finalPrompt,
                negativePrompt = negativePrompt,
                width = bitmap.width,
                height = bitmap.height,
                steps = steps.toInt().coerceAtLeast(1),
                cfgScale = cfgScale.toDouble(),
                flowShift = flowShift.toDouble(),
                strength = strength.toDouble(),
                seed = parsedSeed,
                mode = if (useImg2Img) QwenEngineClient.Mode.IMG2IMG else QwenEngineClient.Mode.EDITS,
                sendExtraArgs = sendExtraArgs
            )

            val output = client.edit(bitmap, mask, params)

            pollJob?.cancel()
            running = false
            engineClient = null

            if (output.bitmap != null) {
                result = output.bitmap
                progress = 1f
                status = "완성! 위 비교 그림을 움직여서 확인하고 저장해."
            } else {
                status = "실패 — " + (output.error ?: "알 수 없는 오류")
            }
        }
    }

    fun cancel() {
        engineClient?.cancel()
        running = false
        status = "취소했어."
        engineClient = null
    }

    fun saveResult(): Boolean {
        val bitmap = result ?: return false
        val name = "qwen_outfit_" + System.currentTimeMillis()
        val ok = ImageUtils.saveToGallery(getApplication(), bitmap, name)
        status = if (ok) "갤러리 > Pictures/QwenOutfit 에 저장했어." else "저장에 실패했어."
        return ok
    }

    override fun onCleared() {
        super.onCleared()
        cancel()
        maskBitmap = null
    }
}