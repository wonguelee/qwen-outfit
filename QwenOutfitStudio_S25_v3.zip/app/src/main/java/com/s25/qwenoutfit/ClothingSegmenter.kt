package com.s25.qwenoutfit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenterResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * 옷(의상)만 자동으로 골라내는 부분.
 *
 * MediaPipe 의 "셀피 여러 부위 인식" 모델(selfie_multiclass_256x256.tflite)이
 * 사진의 모든 픽셀을 6가지로 나눠준다.
 *   0 = 배경, 1 = 머리카락, 2 = 몸 피부, 3 = 얼굴 피부, 4 = 옷, 5 = 액세서리
 *
 * 그래서 4번(옷)만 흰색으로 칠하면 "얼굴·머리·배경은 건드리지 않고 옷만 바꾸는"
 * 마스크가 자동으로 만들어진다. 모델 파일이 없거나 실패하면 null 을 돌려주고,
 * 앱은 손가락 브러시(또는 매직 선택)로 넘어간다.
 */
class ClothingSegmenter(private val context: Context) {

    companion object {
        const val MODEL_ASSET = "selfie_multiclass_256x256.tflite"
        const val CATEGORY_BACKGROUND = 0
        const val CATEGORY_HAIR = 1
        const val CATEGORY_BODY_SKIN = 2
        const val CATEGORY_FACE_SKIN = 3
        const val CATEGORY_CLOTHES = 4
        const val CATEGORY_ACCESSORY = 5
    }

    private var segmenter: ImageSegmenter? = null

    fun modelAvailable(): Boolean {
        return try {
            context.assets.open(MODEL_ASSET).use { true }
        } catch (e: Exception) {
            false
        }
    }

    private fun ensureSegmenter(): ImageSegmenter? {
        val cached = segmenter
        if (cached != null) return cached
        if (!modelAvailable()) return null
        return try {
            val options = ImageSegmenter.ImageSegmenterOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build())
                .setRunningMode(RunningMode.IMAGE)
                .setOutputCategoryMask(true)
                .setOutputConfidenceMasks(false)
                .build()
            ImageSegmenter.createFromOptions(context, options).also { segmenter = it }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * @param keepFaceAndHair true 면 옷 영역만, false 면 옷+몸 피부까지 선택한다.
     * @return 원본과 같은 크기의 화면용 마스크(선택된 곳만 반투명 빨강). 실패하면 null.
     */
    suspend fun clothesMask(source: Bitmap, keepFaceAndHair: Boolean): Bitmap? {
        val small = withContext(Dispatchers.IO) { detectCategories(source) } ?: return null
        val colorPixels = IntArray(small.width * small.height)
        small.getPixels(colorPixels, 0, small.width, 0, 0, small.width, small.height)

        val selected = BooleanArray(colorPixels.size)
        for (i in colorPixels.indices) {
            val category = Color.red(colorPixels[i])
            selected[i] = when {
                category == CATEGORY_CLOTHES -> true
                !keepFaceAndHair && category == CATEGORY_BODY_SKIN -> true
                else -> false
            }
        }
        return withContext(Dispatchers.Default) { buildMaskBitmap(selected, small.width, small.height, source) }
    }

    /** 모델을 돌려서 "부위 번호"만 담긴 작은 비트맵(픽셀의 R 값 = 부위 번호)을 얻는다. */
    private suspend fun detectCategories(source: Bitmap): Bitmap? {
        val engine = ensureSegmenter() ?: return null
        return try {
            val mpImage = BitmapImageBuilder(source).build()
            suspendCancellableCoroutine { continuation ->
                try {
                    engine.segment(mpImage) { result: ImageSegmenterResult ->
                        var out: Bitmap? = null
                        try {
                            val optional = result.categoryMask()
                            if (optional.isPresent) {
                                val mask = optional.get()
                                val width = mask.width
                                val height = mask.height
                                val buffer = mask.getBuffer()
                                if (buffer != null && width > 0 && height > 0) {
                                    buffer.rewind()
                                    val raw = ByteArray(width * height)
                                    buffer.get(raw)
                                    val pixels = IntArray(width * height)
                                    for (i in pixels.indices) {
                                        val category = raw[i].toInt() and 0xFF
                                        pixels[i] = Color.rgb(category, category, category)
                                    }
                                    out = Bitmap.createBitmap(
                                        pixels, width, height, Bitmap.Config.ARGB_8888
                                    )
                                }
                            }
                        } catch (e: Exception) {
                            out = null
                        } finally {
                            result.close()
                        }
                        if (continuation.isActive) continuation.resume(out)
                    }
                } catch (e: Exception) {
                    if (continuation.isActive) continuation.resume(null)
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * 작은(예: 256x256) 부위 지도를 원본 크기로 늘리면서,
     * 경계를 4픽셀 정도 안쪽으로 줄여서 피부·머리카락을 건드리지 않게 한다.
     */
    private fun buildMaskBitmap(
        selected: BooleanArray,
        width: Int,
        height: Int,
        source: Bitmap
    ): Bitmap? {
        if (width <= 2 || height <= 2) return null
        val eroded = erode(selected, width, height)
        val smallPixels = IntArray(width * height)
        for (i in smallPixels.indices) {
            smallPixels[i] = if (eroded[i]) Color.argb(150, 255, 70, 90) else Color.TRANSPARENT
        }
        val small = Bitmap.createBitmap(smallPixels, width, height, Bitmap.Config.ARGB_8888)
        val mask = ImageUtils.createEmptyMask(source.width, source.height)
        val canvas = android.graphics.Canvas(mask)
        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            alpha = 255
        }
        canvas.drawBitmap(
            small,
            android.graphics.Rect(0, 0, width, height),
            android.graphics.Rect(0, 0, source.width, source.height),
            paint
        )
        small.recycle()
        return mask
    }

    /** 1픽셀 침식 — 선택 영역을 살짝 줄여 경계(피부)를 보호한다. */
    private fun erode(src: BooleanArray, width: Int, height: Int): BooleanArray {
        val out = BooleanArray(src.size)
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val i = y * width + x
                if (!src[i]) continue
                out[i] = src[i - 1] && src[i + 1] && src[i - width] && src[i + width]
            }
        }
        return out
    }
}