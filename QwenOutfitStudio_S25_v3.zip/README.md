# Qwen 의상 스튜디오 (갤럭시 S25용)

폰 안에서만 돌아가는 AI로 **얼굴·포즈는 그대로 두고 옷만** 바꾸는 앱입니다.

- **① 옷 자동 선택** — 사진에서 옷 영역을 자동으로 찾아줍니다 (얼굴·머리 보호)
- **② 손으로 칠하기** — 브러시 / 지우개로 마스크를 직접 수정
- **③ 내가 쓴 프롬프트** — 원하는 옷을 직접 입력 (프리셋 버튼도 있음)
- **④ 인페인팅** — 선택한 부분만 다시 그림, 진행률 % 표시

---

## 0. 먼저 이것만 알면 됩니다 (가장 중요)

이전 버전은 **앱 안에 12GB짜리 모델을 넣어서 APK로 굽는** 구조였고, 그래서 계속 실패했습니다.

이번 v3는 구조가 다릅니다.

| | 하는 일 |
|---|---|
| **앱 (APK)** | 사진 보여주기, 옷 영역 칠하기, 프롬프트 입력, 결과 저장 |
| **엔진 (별도)** | 실제로 AI가 그림을 그리는 부분 (`sd-server`) |

앱은 `http://127.0.0.1:1234` 같은 주소로 **엔진에게 부탁만** 합니다. 실제로 잘 돌아가는 앱들이 전부 이 방식입니다.

> ⚠️ **솔직한 한계**: 갤럭시 S25는 RAM이 12GB입니다. Qwen-Image-Edit-2509 Q4 모델은 약 11~12GB라, **폰 RAM에 통째로 올리는 건 무리**입니다. 그래서 **PC에 엔진을 두는 방식(A)을 권장**합니다. 폰 단독(B)도 이론상 가능하지만 느리고(한 장에 10분 이상) 메모리 부족으로 실패할 가능성이 큽니다.

---

## 1. 전체 그림

```mermaid
flowchart LR
    A["📱 앱 (APK)<br/>사진 · 마스크 · 프롬프트"] -->|"http 요청"| B["🖥️ 엔진 (sd-server)<br/>127.0.0.1:1234 또는 PC 주소"]
    B --> C["Qwen-Image-Edit-2509<br/>Q4 GGUF 모델"]
    C -->|"바뀐 사진"| A
    A --> D["🖼️ 갤러리 저장"]
```

---

## 2. 엔진 준비

### 방법 A — PC에 엔진 두기 (권장) ⭐

1. **엔진 프로그램 받기**: [stable-diffusion.cpp Releases](https://github.com/leejet/stable-diffusion.cpp/releases) 에서 자기 PC에 맞는 압축파일을 받습니다.
   - 윈도우 + NVIDIA 그래픽카드 → `cuda` 들어간 것
   - 윈도우 + 일반 → `cpu` 또는 `vulkan` 들어간 것
2. 압축을 풀면 `sd-server.exe`(윈도우) 또는 `sd-server`(리눅스/맥)가 있습니다.
3. 아래 3번 항목의 **모델 4개**를 받아서 폴더를 이렇게 만듭니다.

```text
qwen/
├─ sd-server.exe
└─ models/
   ├─ diffusion_models/
   │   └─ Qwen-Image-Edit-2509-Q4_K_S.gguf
   ├─ text_encoders/
   │   ├─ Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf
   │   └─ mmproj-Qwen2.5-VL-7B-Instruct-Q8_0.gguf
   └─ vae/
       └─ qwen_image_vae.safetensors
```

4. 명령 창(윈도우는 `cmd`)에서 다음 **한 줄**을 붙여넣습니다.

```bat
sd-server.exe --diffusion-model models\diffusion_models\Qwen-Image-Edit-2509-Q4_K_S.gguf --llm models\text_encoders\Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf --llm_vision models\text_encoders\mmproj-Qwen2.5-VL-7B-Instruct-Q8_0.gguf --vae models\vae\qwen_image_vae.safetensors --cfg-scale 2.5 --sampling-method euler --flow-shift 3 --listen-ip 0.0.0.0 --offload-to-cpu -v
```

> 🔎 **`--llm_vision` 는 밑줄(`_`)입니다.** 예전에 빼기표(`-`)로 넣어서 앱이 0.1초 만에 꺼졌던 그 부분입니다. (출처: [stable-diffusion.cpp 공식 문서](https://github.com/leejet/stable-diffusion.cpp/blob/master/docs/qwen_image_edit.md))

5. 성공하면 창에 `http://127.0.0.1:1234/` 라고 뜨고 거기서 멈춥니다. **이 창을 닫으면 안 됩니다.**
6. **PC의 IP 주소**를 확인합니다 (윈도우: `cmd` 에서 `ipconfig` → `IPv4 주소` 예: `192.168.0.5`).
7. 폰과 PC를 **같은 와이파이**에 연결하고, 앱의 `설정 → 엔진 주소`에 `http://192.168.0.5:1234` 처럼 넣습니다.

> 🛡️ 윈도우 방화벽이 물어보면 **개인 네트워크 허용**을 눌러야 폰에서 접속됩니다.

### 방법 B — 폰에서만 (Termux, 실험적)

폰 하나로 끝내고 싶다면 [Termux](https://f-droid.org/packages/com.termux/)를 설치하고 그 안에서 위 엔진을 직접 빌드해야 합니다.
**이 방식은 제가 "된다"고 보장할 수 없습니다.** 폰 CPU로 도는 거라 한 장에 10분 이상 걸리고, 12GB RAM에 12GB 모델을 올리는 것 자체가 빠듯합니다. 먼저 A로 성공해 본 다음 시도하길 권합니다.

---

## 3. 모델 4개 받기 (약 17GB, 와이파이 필수)

| 순서 | 파일 | 용량 | 받는 곳 |
|---|---|---|---|
| 1 | `Qwen-Image-Edit-2509-Q4_K_S.gguf` | 약 11~12GB | [QuantStack/Qwen-Image-Edit-2509-GGUF](https://huggingface.co/QuantStack/Qwen-Image-Edit-2509-GGUF/tree/main) |
| 2 | `Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf` | 약 4.7GB | [ggml-org/Qwen2.5-VL-7B-Instruct-GGUF](https://huggingface.co/ggml-org/Qwen2.5-VL-7B-Instruct-GGUF/tree/main) |
| 3 | `mmproj-Qwen2.5-VL-7B-Instruct-Q8_0.gguf` | 약 850MB | 위와 같은 페이지 (3번 항목) |
| 4 | `qwen_image_vae.safetensors` | 약 254MB | [Comfy-Org/Qwen-Image_ComfyUI / split_files/vae](https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI/tree/main/split_files/vae) |

**메모리가 빠듯하면** 1번 대신 같은 페이지에 있는 더 가벼운 `Q3_K_S` 나 `Q2_K` 를 받아도 됩니다 (화질은 조금 떨어집니다).

> 파일 이름은 위 표의 이름과 **정확히 같아야** 합니다. 다운로드가 중간에 끊기면 엔진이 읽다가 멈춥니다. 용량을 꼭 확인하세요.

---

## 4. APK 만들기 (깃허브에서 자동 조립, 6단계)

내 컴퓨터에 개발 프로그램을 깔 필요가 없습니다. 깃허브 서버가 대신 조립해 줍니다.

### 1단계 — 깃허브 가입/로그인
[github.com](https://github.com) → **Sign up** (이미 있으면 Sign in)

> 📱 폰으로 할 때 꿀팁: 브라우저 메뉴 `⋮` → **데스크톱 사이트**를 켜면 버튼 찾기 쉬워요.

### 2단계 — 저장소 만들기
오른쪽 위 `+` → **New repository** → 이름에 `qwen-outfit` → **Public** → **Create repository**

### 3단계 — zip 파일 올리기
저장소 화면에서 **uploading an existing file** 링크(또는 **Add file → Upload files**)를 누르고, `QwenOutfitStudio_S25_v3.zip` 을 **압축 풀지 말고 그대로** 끌어다 놓고 **Commit changes**.

### 4단계 — 조립 주문서 만들기 (여기가 제일 중요!)
1. 저장소에서 **Add file → Create new file**
2. 파일 이름 칸에 정확히 이렇게 입력:
   ```
   .github/workflows/build.yml
   ```
   (`.github/workflows/` 를 입력하면 자동으로 폴더가 생깁니다)
3. 아래 **전체를 복사**해서 붙여넣기:

```yaml
name: Build APK
on:
  push:
    branches: [main, master]
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.11.1'
      - name: 안드로이드 SDK 부품 준비
        run: |
          SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
          if [ -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
            yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --install "platforms;android-35" "build-tools;35.0.0" >/dev/null 2>&1 || true
          fi
      - name: 올린 zip 파일 자동으로 풀기
        run: |
          set -e
          shopt -s nullglob
          for z in *.zip; do unzip -o "$z"; done
          if [ -d QwenOutfitStudio ] && [ ! -f settings.gradle.kts ]; then cp -r QwenOutfitStudio/. .; fi
          ls -la
      - name: 옷 인식 모델 내려받기
        continue-on-error: true
        run: |
          mkdir -p app/src/main/assets
          TARGET="app/src/main/assets/selfie_multiclass_256x256.tflite"
          URL="https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_multiclass_256x256/float32/latest/selfie_multiclass_256x256.tflite"
          if [ ! -s "$TARGET" ]; then
            curl -fL --retry 3 --retry-delay 2 -o "$TARGET" "$URL" || echo "모델 내려받기 실패 — 자동 선택만 못 씀"
          fi
          ls -la app/src/main/assets || true
      - name: APK 조립
        run: gradle --no-daemon assembleDebug
      - name: APK 올려두기
        uses: actions/upload-artifact@v4
        with:
          name: QwenOutfitStudio-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
```

4. 아래로 내려 **Commit changes** 누르기.

### 5단계 — 기다리기
저장소 위쪽 **Actions** 탭을 누르면 노란 점(⏳)이 돌아갑니다. 5~10분 기다리면 **초록 체크(✅)** 로 바뀝니다.

### 6단계 — APK 내려받기
1. 초록 체크가 된 항목을 클릭
2. 맨 아래 **Artifacts** 에 `QwenOutfitStudio-apk` → 눌러서 내려받기 (zip으로 받아집니다)
3. 압축을 풀면 `app-debug.apk` 가 나옵니다
4. 폰에서 이 파일을 눌러 **"출처를 알 수 없는 앱 설치 허용"** 을 켜고 설치

> ❌ **빨간 X(실패)** 가 뜨면, 항목을 눌러 **어느 단계에서 멈췄는지** 이름을 확인해서 알려주세요. (예: `APK 조립` 에서 멈춤)

---

## 5. 앱 사용법

1. **사진 불러오기** — 인물이 크게 나온 사진을 고릅니다
2. **옷 자동 선택** 을 누릅니다 → 옷 부분만 빨갛게 칠해집니다
   - 자동 결과가 마음에 안 들면 **브러시/지우개**로 직접 손봅니다
   - 얼굴이 같이 선택되면 `자동 선택 시 얼굴·머리카락 보호` 스위치를 켜세요
3. **프롬프트**에 원하는 옷을 씁니다 (예: `black leather jacket`)
   - 아래 프리셋 버튼을 누르면 자동으로 들어갑니다
   - `얼굴·포즈·배경 유지 문구 자동 추가` 는 **켜두세요** (목적이 그거니까)
4. **옷 바꾸기 실행** 을 누릅니다
5. 결과가 나오면 슬라이더를 움직여 **원본 ↔ 결과** 를 비교하고 **갤러리에 저장**

> 💡 **결과가 반대로 나올 때** (옷이 아니라 배경이 바뀔 때): 엔진 버전에 따라 마스크의 흰/검정 의미가 반대일 수 있습니다. 사진 카드의 **`반전`** 버튼을 누르고 다시 실행하세요.

### 설정 화면에서 조절할 것

| 항목 | 기본값 | 설명 |
|---|---|---|
| 엔진 주소 | `http://127.0.0.1:1234` | PC 엔진이면 `http://192.168.x.x:1234` |
| 인페인팅 모드 | 꺼짐 | 켜면 진행률 %와 미리보기가 보입니다 |
| 엔진 세부옵션 | 켜짐 | 엔진이 못 받으면 앱이 자동으로 옵션 없이 다시 시도합니다 |
| 스텝 | 8 | 높이면 느리고 조금 더 정교 |
| CFG | 2.5 | 프롬프트를 얼마나 강하게 반영할지 |
| Flow shift | 3 | Qwen 권장값 그대로 두세요 |
| 변화 강도 | 0.85 | 너무 높으면 얼굴도 변할 수 있어요 |
| 시드 | -1 | -1은 매번 랜덤. 마음에 든 결과의 시드를 적으면 재현됩니다 |

---

## 6. 안 되면 여기부터 (자주 겪은 오류)

| 증상 | 원인 | 해결 |
|---|---|---|
| `엔진에 연결할 수 없어` | 엔진이 꺼져 있거나 주소가 틀림 | 엔진 창이 켜져 있는지, 같은 와이파이인지 확인. 윈도우 방화벽에서 개인 네트워크 허용 |
| `엔진은 켜졌지만 모델이 아직 로드되지 않았어` | 모델 로딩 중이거나 파일 경로 오류 | 엔진 창 로그 확인. 모델 4개 파일 이름·용량 확인 |
| 실행하자마자 실패 | `--llm_vision` 오타 / 모델 미로드 | 위 2번 항목의 명령을 **그대로** 복사해서 쓰세요 (밑줄!) |
| 결과가 배경만 바뀜 | 마스크 흰/검정이 반대 | 앱의 **`반전`** 버튼 |
| 옷 자동 선택이 안 됨 | 옷 인식 모델이 앱에 없음 | 자동 조립을 쓰면 자동으로 들어갑니다. 안 되면 손으로 칠하세요 |
| 얼굴도 같이 변함 | 변화 강도가 너무 높음 | `변화 강도` 를 0.6~0.75로 낮추기 |
| APK 조립 실패 (`exit code 1/2`) | 주문서 붙여넣기 오류 | 4단계의 yml 을 **전체 복사**로 다시 붙여넣기 |

---

## 7. 프로젝트 구조 (참고)

```text
QwenOutfitStudio/
├─ settings.gradle.kts / build.gradle.kts / gradle.properties
├─ .github/workflows/build.yml          ← 자동 APK 조립 주문서
├─ README.md                            ← 지금 이 문서
└─ app/
   ├─ build.gradle.kts
   └─ src/main/
      ├─ AndroidManifest.xml            (로컬 주소만 통신 허용)
      ├─ assets/PUT_MODEL_HERE.txt      (조립 때 옷 인식 모델 자동 삽입)
      ├─ res/…                          (아이콘·테마·색)
      └─ java/com/s25/qwenoutfit/
         ├─ MainActivity.kt             화면 전체 (Compose UI)
         ├─ StudioViewModel.kt          상태·마스크·실행·저장
         ├─ ClothingSegmenter.kt        옷 자동 선택 (MediaPipe 6분류)
         ├─ QwenEngineClient.kt         엔진 통신 (실패 시 자동 재시도)
         └─ ImageUtils.kt               사진 불러오기·마스크 변환·저장
```

---

## 출처

- 엔진: [leejet/stable-diffusion.cpp](https://github.com/leejet/stable-diffusion.cpp) · [Qwen Image Edit 문서](https://github.com/leejet/stable-diffusion.cpp/blob/master/docs/qwen_image_edit.md) · [서버 API 문서](https://github.com/leejet/stable-diffusion.cpp/blob/master/examples/server/api.md)
- 옷 인식: [MediaPipe Image Segmenter](https://developers.google.com/edge/mediapipe/solutions/vision/image_segmenter) (selfie_multiclass_256x256, 15.6MB)
- 모델: [QuantStack/Qwen-Image-Edit-2509-GGUF](https://huggingface.co/QuantStack/Qwen-Image-Edit-2509-GGUF) · [ggml-org/Qwen2.5-VL-7B-Instruct-GGUF](https://huggingface.co/ggml-org/Qwen2.5-VL-7B-Instruct-GGUF) · [Comfy-Org/Qwen-Image_ComfyUI](https://huggingface.co/Comfy-Org/Qwen-Image_ComfyUI)

> 이 앱은 인물 사진의 **마스크로 지정한 영역만** 다시 그리는 편집 도구입니다. 타인의 사진을 무단으로 편집·유포하는 용도로 쓰지 마세요.